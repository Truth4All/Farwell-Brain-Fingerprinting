#include <gtk/gtk.h>
#include<iostream>
#include<graphics>
using namespace std;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogInstaller
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Farwell1BrainFingerprintingLogInstaller.InstallFarwell2BrainFingerprintingLogging();
            }
            catch(Exception ex)
            {

            }
        }
    }
}

