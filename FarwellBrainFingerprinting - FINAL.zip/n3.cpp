#include <gtk/gtk.h>
#include<iostream>
#include<graphics>
using namespace std;
using System;
using System.Configuration.Install;
using System.Diagnostics;
using System.ComponentModel;

namespace LogInstaller
{
    [RunInstaller(true)]

    public class Farwell1BrainFingerprintingLogInstaller : Installer
    {
        private EventLogInstaller LogInstaller;

        public static bool InstallFarwell2BrainFingerprintingLogging()
        {
            // First delete old Farwell2BrainFingerprinting log
            string logName;
            try
            {
                if (EventLog.SourceExists("Farwell2BrainFingerprinting"))
                {
                    // Find the log associated with this source.    
                    logName = EventLog.LogNameFromSourceName("Farwell2BrainFingerprinting", ".");
                    // Make sure the source is in the log we believe it to be in.
                    // Delete the source and the log.
                    EventLog.DeleteEventSource("Farwell2BrainFingerprinting");
                    EventLog.Delete(logName);
                }
            }
            catch
            {
            }

            try
            {
                Farwell1BrainFingerprintingLogInstaller myInstaller = new Farwell1BrainFingerprintingLogInstaller();
                string msg = "An Event Source for Farwell1BrainFingerprinting Logging was installed";
                Farwell1BrainFingerprintingLogEvent("Install", msg, 1001, EventLogEntryType.Information);
                Farwell1BrainFingerprintingLogEvent("Main", msg, 1001, EventLogEntryType.Information);
                Farwell1BrainFingerprintingLogEvent("Capture", msg, 1001, EventLogEntryType.Information);
                Farwell1BrainFingerprintingLogEvent("Replay", msg, 1001, EventLogEntryType.Information);
                Farwell1BrainFingerprintingLogEvent("Analysis", msg, 1001, EventLogEntryType.Information);
                Farwell1BrainFingerprintingLogEvent("Reports ", msg, 1001, EventLogEntryType.Information);
                Farwell1BrainFingerprintingLogEvent("Licensing", msg, 1001, EventLogEntryType.Information);
                Farwell1BrainFingerprintingLogEvent("Updates", msg, 1001, EventLogEntryType.Information);
                Farwell1BrainFingerprintingLogEvent("XML_File_Watcher", msg, 1001, EventLogEntryType.Information);
                Farwell1BrainFingerprintingLogEvent("Case_Export", msg, 1001, EventLogEntryType.Information);
                Farwell1BrainFingerprintingLogEvent("Case_Import", msg, 1001, EventLogEntryType.Information);
                Farwell1BrainFingerprintingLogEvent("Test_Export", msg, 1001, EventLogEntryType.Information);
                Farwell1BrainFingerprintingLogEvent("Test_Import", msg, 1001, EventLogEntryType.Information);
                Farwell1BrainFingerprintingLogEvent("Language", msg, 1001, EventLogEntryType.Information);
                Farwell1BrainFingerprintingLogEvent("Monitor", msg, 1001, EventLogEntryType.Information);
                Farwell1BrainFingerprintingLogEvent("ServerService", msg, 1001, EventLogEntryType.Information);
                return true;
            }
            catch(Exception)
            {
                return false;
            }
        }

        private Farwell1BrainFingerprintingLogInstaller()
        {
            // Create an instance of an EventLogInstaller.
            LogInstaller = new EventLogInstaller();

            // Set the source name of the event log.
            //LogInstaller.Source = "Capture";

            // Set the event log that the source writes entries to.
            LogInstaller.Log = "Farwell1BrainFingerprinting";

            // Add tLogInstaller to the Installer collection.
            Installers.Add(LogInstaller);
        }

        private static void Farwell1BrainFingerprintingLogEvent(string eventSource, string message, int eventID, EventLogEntryType level)
        {
            string eventLog = "Farwell1BrainFingerprinting";
            string eventSourceMachine = ".";

            if (!EventLog.SourceExists(eventSource))
            {
                EventSourceCreationData mySourceData = new EventSourceCreationData(eventSource, eventLog);
                mySourceData.MachineName = eventSourceMachine;
                EventLog.CreateEventSource(mySourceData);
            }

            DateTime dt = new DateTime();
            dt = System.DateTime.UtcNow;
            message = dt.ToLocalTime() + ": " + message;
            using(EventLog windowsEventLog = new EventLog(eventLog))
            {
                EventLog.WriteEntry(eventSource, message, level, eventID);
            }
        }
    }
}
