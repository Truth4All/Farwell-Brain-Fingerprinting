#include <gtk/gtk.h>
#include<iostream>
#include<graphics>
using namespace std;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace Farwell2BrainFingerprinting.Replay
{
    public partial class post_test_comments : Form
    {
        private bool saveState = false;
        private bool saveChecked = false;
        public static string txtComments;

        public post_test_comments(bool _saveChecked)
        {
            InitializeComponent();

            // Language override
            if (conf.Language != "en-US")
            {
                this.Text           = conf.GetLanguageString("e06b72bd-c8f2-483e-b722-ccd944248c4e"); // "Post test comments"
                this.btnSave.Text   = conf.GetLanguageString("0a0a1aec-0e91-4546-b6f9-f29f2ac19533"); // " Save"
            }

            txtComment.Text = frmDisplayCapture.Comments;
            saveChecked = _saveChecked;
        }  

        private void btnSave_Click(object sender, EventArgs e)
        {
            saveComment();
        }

        private void post_test_comments_FormClosed(object sender, FormClosedEventArgs e)
        {
            if(!saveState)
                saveComment();
        }

        private void saveComment()
        {
            frmDisplayCapture.Comments = txtComment.Text;
            saveState = true;
            this.Close();
        }
    }
}

