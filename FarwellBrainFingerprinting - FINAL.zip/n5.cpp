#include <gtk/gtk.h>
#include<iostream>
#include<graphics>
using namespace std;
using Microsoft.Win32;
using System;
using System.Configuration;
using System.Data;
using System.DirectoryServices.AccountManagement;
using System.Globalization;
using System.IO;
using System.Threading;
using System.Xml;

namespace Farwell2BrainFingerprinting.Replay
{
    public partial class Configuration
    {
        string configPath = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles) + @"\Farwell1BrainFingerprinting\config";

        public static string filePath;
        public Farwell2BrainFingerprinting.Xml.XmlDocument InputDocument;
        public DataTable ConfigurationTable;
        public DataTable LanguageTable;

        // Capure Test and subject data
        public string TestGUID;             // Test GUID
        public string SetGUID;              // Set GUID
        public string CaseGUID;             // From BF_Cases.GUID
        public string CaseJurisdictionID;   // From BF_Cases.JurisdictionID
        public string subjectGUID;          // From BF_Subjects.GUID 
        public string subjectName;          // From BF_Subjects.Firstname+" "+BF_Subjects.Lastname
        public string TestSetupGUID;        // TestSetup GUID used for this test
        public string ProtocolGUID;         // Protocol GUID used for this test
        public string Language;             // Language used by the operator
        public string UserSID;              // Security Identifier of the Operator
        public string Location;             // Test Location
        public string MachineName;          // Machine Name that conducted the test
        public string StartDateTime;        // Timestamp on when the test was started
        public string EndDateTime;          // Timestamp on when the test was ended
        public string Comments;             // Comments written during the test
        

        // Stimulus parameters
        
        public string StimulusModality; // text,image,audio,video
        public int SamplingFrequency;   // System Sampling Rate
        public int Resolution;          // 
        public int PGAGain;             // 
        public int Channels;            // 
        public int ERPInterval;         // Stimulus Interval:3000
        public int ERPBaseline;         // Data epoch post-Stimulus:2800
        public int Fixation;            // Fixation time prior Stimulus onset:1000
        public int Exposure;            // Duration of the stimulus exposure: 400
        public int CaptureDuration;     // Capture Duration:3800
        public int AnswerWindow;        // Valid period for answer validation capture
        public int DisplayTime;         // Display Time:4000
        public int TargetsRequired;     // Required number of good Target trials:12
        public int ProbesRequired;      // Required number of good Probe trials:12
        public int IrrelevantsRequired; // Required number of good Irrelevant trials:36
        public int EOGRange;            // Max allowable range for EOG channels:2000
        public int EEGRange;            // Max allowable range for EEG channels:2000

        // Headset parameters
        public int PreAmpGain;          // Front-end EEG amplifier gain:1365
        public float RefVoltage;        // Internal Headset Reference (Volts):4.0

        //File Archive Information
        public StreamWriter fileSWriter;

        public Configuration()
        {
            XmlDocument InputDocument   = new XmlDocument();

            // Language Table
            Language = GetUserLanguage();            // Language used by the operator
            string BF_LanguageAsset = String.Format(@"{0}\BF_Language_{1}.xml", configPath, Language);
            DataSet ds_LanguageAsset = new DataSet();
            ds_LanguageAsset.ReadXml(BF_LanguageAsset);
            LanguageTable = ds_LanguageAsset.Tables[0];

            // Read XML input document to get used configuration parameters
            filePath = GetCommonAllUsersXMLCaptureDataFolder() + Program.PassedGUID + ".rxml";
            InputDocument.Load(filePath);

            // Data from XML file
            CaseGUID            = InputDocument.SelectSingleNode("/Farwell2BrainFingerprinting_Test/Test-Case/GUID").InnerText; //(R)
            subjectGUID         = InputDocument.SelectSingleNode("/Farwell2BrainFingerprinting_Test/Test-Subjects/Test-Subject/GUID").InnerText; //(R)

            UserSID             = (InputDocument.SelectSingleNode("/Farwell2BrainFingerprinting_Test/Test-Tests/Test/TestOperatorSID") != null) ? InputDocument.SelectSingleNode("/Farwell2BrainFingerprinting_Test/Test-Tests/Test/TestOperatorSID").InnerText : ""; //(O)
            Location            = (InputDocument.SelectSingleNode("/Farwell2BrainFingerprinting_Test/Test-Tests/Test/TestLocation") != null)    ? InputDocument.SelectSingleNode("/Farwell2BrainFingerprinting_Test/Test-Tests/Test/TestLocation").InnerText : ""; //(O)
            MachineName         = (InputDocument.SelectSingleNode("/Farwell2BrainFingerprinting_Test/Test-Tests/Test/MachineName") != null)     ? InputDocument.SelectSingleNode("/Farwell2BrainFingerprinting_Test/Test-Tests/Test/MachineName").InnerText : ""; //(O)
            SamplingFrequency   = Convert.ToInt32(InputDocument.SelectSingleNode("/Farwell2BrainFingerprinting_Test/Test-Tests/Test/SamplingFrequency").InnerText); //(O)
            Channels            = Convert.ToInt32(InputDocument.SelectSingleNode("/Farwell2BrainFingerprinting_Test/Test-Tests/Test/Channels").InnerText); //(O)

            Channels            = 2; //Overide for replay (only two channels are recorded)

            Resolution          = Convert.ToInt32(InputDocument.SelectSingleNode("/Farwell2BrainFingerprinting_Test/Test-Tests/Test/Resolution").InnerText); //(O)
            PGAGain             = Convert.ToInt32(InputDocument.SelectSingleNode("/Farwell2BrainFingerprinting_Test/Test-Tests/Test/PGAGain").InnerText); //(O)
            StimulusModality    = InputDocument.SelectSingleNode("/Farwell2BrainFingerprinting_Test/Test-Tests/Test/StimulusModality").InnerText; //(O)
            Fixation            = Convert.ToInt32(InputDocument.SelectSingleNode("/Farwell2BrainFingerprinting_Test/Test-Tests/Test/Fixation").InnerText); //(O)
            Exposure            = Convert.ToInt32(InputDocument.SelectSingleNode("/Farwell2BrainFingerprinting_Test/Test-Tests/Test/Exposure").InnerText); //(O)
            ERPInterval         = Convert.ToInt32(InputDocument.SelectSingleNode("/Farwell2BrainFingerprinting_Test/Test-Tests/Test/ERPInterval").InnerText); //(O)
            ERPBaseline         = Convert.ToInt32(InputDocument.SelectSingleNode("/Farwell2BrainFingerprinting_Test/Test-Tests/Test/ERPBaseline").InnerText); //(O)
            EOGRange            = Convert.ToInt32(InputDocument.SelectSingleNode("/Farwell2BrainFingerprinting_Test/Test-Tests/Test/EOGRange").InnerText);//(O)
            EEGRange            = Convert.ToInt32(InputDocument.SelectSingleNode("/Farwell2BrainFingerprinting_Test/Test-Tests/Test/EEGRange").InnerText);//(O)
            CaptureDuration     = Convert.ToInt32(InputDocument.SelectSingleNode("/Farwell2BrainFingerprinting_Test/Test-Tests/Test/CaptureDuration").InnerText);//(O)
            AnswerWindow        = Convert.ToInt32(InputDocument.SelectSingleNode("/Farwell2BrainFingerprinting_Test/Test-Tests/Test/AnswerWindow").InnerText);//(O)
            TargetsRequired     = Convert.ToInt32(InputDocument.SelectSingleNode("/Farwell2BrainFingerprinting_Test/Test-Tests/Test/TargetsRequired").InnerText);//(O)
            ProbesRequired      = Convert.ToInt32(InputDocument.SelectSingleNode("/Farwell2BrainFingerprinting_Test/Test-Tests/Test/ProbesRequired").InnerText);//(O)
            IrrelevantsRequired = Convert.ToInt32(InputDocument.SelectSingleNode("/Farwell2BrainFingerprinting_Test/Test-Tests/Test/IrrelevantsRequired").InnerText);//(O)
            Comments            = (InputDocument.SelectSingleNode("/Farwell2BrainFingerprinting_Test/Test-Tests/Test/Comments") != null)       ? InputDocument.SelectSingleNode("/Farwell2BrainFingerprinting_Test/Test-Tests/Test/Comments").InnerText : "";//(O)


            StartDateTime       = InputDocument.SelectSingleNode("/Farwell2BrainFingerprinting_Test/Test-Tests/Test/Trials/Trial[1]/CaptureTime").InnerText; //(R)
            EndDateTime         = InputDocument.SelectSingleNode("/Farwell2BrainFingerprinting_Test/Test-Tests/Test/Trials/Trial[last()]/CaptureTime").InnerText; //(R)

            StimulusParameter.GetStimuliDataFromXML(InputDocument);
            
            // Hard-coded in the configuration (will be moved to .conf at later time)
            DisplayTime         = 5000; // in mS
            PreAmpGain          = 1365; // integer of front-end gain
            RefVoltage          = 2.4f; // float value of the reference voltage (2.33)
        }

        public string ConnectionString
        {
            get { return ConfigurationManager.ConnectionStrings["DefaultDBConnection"].ToString(); }
        }

        public string GetUserLanguage()
        {
            string language;
            CultureInfo currentCulture = Thread.CurrentThread.CurrentCulture;
            Microsoft.Win32.RegistryKey wkey;
            Microsoft.Win32.RegistryKey rkey;

            // Create a HKEY_CURRENT_USER\SOFTWARE\Farwell2BrainFingerprinting key cluster if it does not exist and assign the first value "LCID" to currentCulture.Name
            // Return the currentLCID whatever the key existed or not.
            RegistryKey key = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Farwell2BrainFingerprinting");
            if (key == null)
            {
                wkey = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(@"SOFTWARE\Farwell2BrainFingerprinting");
                wkey.SetValue("LCID", currentCulture.Name);
                wkey.Close();
                language = currentCulture.Name;
            }
            else
            {
                rkey = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Farwell2BrainFingerprinting");
                if (rkey != null)
                {
                    language = rkey.GetValue("LCID").ToString();
                }
                else
                {
                    language = "en-US";
                }
            }
            return language;
        }

        public string GetConfigurationString(string KeyClassGUID)
        {
            try
            {
                KeyClassGUID = "KeyClassGUID = '" + KeyClassGUID + "'";
                return ConfigurationTable.Select(KeyClassGUID)[0].ItemArray[1].ToString();
            }
            catch
            {
                return "";
            }
        }
        
        public int GetConfigurationInteger(string KeyClassGUID)
        {
            try
            {
                KeyClassGUID = "KeyClassGUID = '" + KeyClassGUID + "'";
                return Convert.ToInt32(ConfigurationTable.Select(KeyClassGUID)[0].ItemArray[1]);
            }
            catch
            {
                return 0;
            }
        }

        public string GetCommonAllUsersXMLCaptureDataFolder()
        {
            string folderBase = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            string dir = string.Format(@"{0}\Farwell1BrainFingerprinting\temp\", folderBase);
            return CheckDir(dir);
        }

        private static string CheckDir(string dir)
        {
            if (!Directory.Exists(dir))
            {
                Directory.CreateDirectory(dir);
            }
            return dir;
        }

        public string GetLanguageString(string AssetGUID)
        {
            try
            {
                AssetGUID = "GUID = '" + AssetGUID + "'";
                return LanguageTable.Select(AssetGUID)[0].ItemArray[3].ToString();
            }
            catch
            {
                return "";
            }
        }

        public string GetOperatorSID()
        {
            return UserPrincipal.Current.Sid.ToString();

        }

        /// <summary>
        /// Convert a time position parameter into a data index in the capture buffer
        /// </summary>
        /// <param name="time">time expressed as an integer in mS</param>
        /// <param name="samplingRate">sampling rate used for data digitization</param>
        /// <param name="offset">zero is the onset of stimulus; the data capture start before that (set at fixation duration(mS))</param>
        /// <returns>return the index position in the data buffer</returns>
        public int Time2DataIndex(int time, int samplingRate, int offset)
        {
            return (int)Math.Truncate((((double)time / 1000) * (double)samplingRate) + (((double)offset / 1000) * (double)samplingRate));
        }

        public int BufferLenght(int time, int samplingRate)
        {
            return (int)Math.Truncate((((double)time / 1000) * (double)samplingRate));
        }

    }
}

