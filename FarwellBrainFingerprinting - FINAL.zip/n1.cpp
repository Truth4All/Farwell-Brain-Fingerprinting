#include <gtk/gtk.h>
#include<iostream>
#include<graphics>
using namespace std;
using Farwell2BrainFingerprinting.Business;
using Farwell2BrainFingerprinting.GlobalHotKey;
using Farwell2BrainFingerprinting.Infrastructure;
using Farwell2BrainFingerprinting.Xbox;
using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Input;
using System.Xml;


namespace Farwell2BrainFingerprinting.Main
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public App()
        {
            var currentDomain = AppDomain.CurrentDomain;
            currentDomain.UnhandledException += CurrentDomain_UnhandledException;
        }

        protected override void OnStartup(StartupEventArgs e)
        {
            try
            {
                // Get the version of the application
                GlobalVariables.ApplicationVersion = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString();

                // FILE STUFF
                // Get the application various directory paths
                GlobalVariables.ConfigPath      = string.Format(@"{0}\Farwell1BrainFingerprinting\config\",      Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles));
                GlobalVariables.DocumentsPath   = string.Format(@"{0}\Farwell1BrainFingerprinting\documents\",   Environment.GetFolderPath(Environment.SpecialFolder.UserProfile));
                GlobalVariables.TempPath        = string.Format(@"{0}\Farwell1BrainFingerprinting\temp\",        Environment.GetFolderPath(Environment.SpecialFolder.UserProfile));
                GlobalVariables.AudioTempPath   = string.Format(@"{0}\Farwell1BrainFingerprinting\audio\",       Environment.GetFolderPath(Environment.SpecialFolder.UserProfile));
                GlobalVariables.Database        = string.Format(@"{0}\Farwell1BrainFingerprinting\database\",    Environment.GetFolderPath(Environment.SpecialFolder.UserProfile));
                GlobalVariables.Backups         = string.Format(@"{0}\Farwell1BrainFingerprinting\backups\",     Environment.GetFolderPath(Environment.SpecialFolder.UserProfile));
                GlobalVariables.TempReplayPath  = string.Format(@"{0}\Farwell1BrainFingerprinting\temp_replay\", Environment.GetFolderPath(Environment.SpecialFolder.UserProfile));
                GlobalVariables.Updates         = string.Format(@"{0}\Farwell1BrainFingerprinting\updates\",     Environment.GetFolderPath(Environment.SpecialFolder.UserProfile));
                GlobalVariables.Capture         = string.Format(@"{0}\Farwell1BrainFingerprinting\capture\",     Environment.GetFolderPath(Environment.SpecialFolder.UserProfile));

                CreateUserFolders(); // Create new AppData user profile directories for Farwell2BrainFingerprinting (needed for new users)
                ClearTemp();  // clear previous session temp directory except the network catalog cache
                InitializeDatabases(); // create all new "databases" if not created (first-time run)
                //CleanupHotKeys(); //Cleanup HotKeys that we are going to use.

                // USER STUFF
                // User profile data
                GlobalVariables.CurrentUserName = Environment.UserName;
                GlobalVariables.CurrentLCID     = Thread.CurrentThread.CurrentCulture.Name;
                GlobalVariables.Domain          = Environment.UserDomainName.ToString();

                // RUNTIME EXCEPTION AND START
                // Check for duplication invocation of Farwell2BrainFingerprinting
                Process thisProc = Process.GetCurrentProcess();
                //if (Process.GetProcessesByName(thisProc.ProcessName).Length > 1)
                //{
                //    MessageBox.Show(@"The application is already running with another user. Please exit the application from another user and try again.");
                //    Application.Current.Shutdown();
                //    return;
                //}

                base.OnStartup(e);

                // CONFIGURATION STUFF
                // Load Master Data (master data is "factory" data, XML files are located in Program Files/config)
                GlobalVariables.MasterData      = Farwell2BrainFingerprinting.DataSet.MasterDataDL.LoadMasterData();
                // Farwell2BrainFingerprinting configuration loading; used for external application paths, manuals and Help document paths
                BFPConfiguration.Load();    // Loads the Farwell2BrainFingerprinting.config configuration file

                // ASSOCIATED HARDWARE
                // XboxKeyboard Service initialization/check/star
                XboxController.Start();

                // Application bootstrapper as per Prism framework.
                BFPBootStrapper bootStrapper = new BFPBootStrapper();
                bootStrapper.Run();         // From Prism Bootstrapper
            }
            catch (Exception ex)
            {
                this.Shutdown();
            }
        }

        ///////////////////  START STUFF ///////////////////
        private void CreateUserFolders()
        {
            CreateIfMissing(string.Format(@"{0}\Farwell1BrainFingerprinting", Environment.GetFolderPath(Environment.SpecialFolder.UserProfile)));
            CreateIfMissing(GlobalVariables.Backups);
            CreateIfMissing(GlobalVariables.Database);
            CreateIfMissing(GlobalVariables.DocumentsPath);
            CreateIfMissing(GlobalVariables.TempPath);
            CreateIfMissing(GlobalVariables.AudioTempPath);
            CreateIfMissing(GlobalVariables.TempReplayPath);
            CreateIfMissing(GlobalVariables.Updates);
            CreateIfMissing(GlobalVariables.Capture);
            CreateEmptyCatalog();
        }

        private void CreateEmptyCatalog()
        {
            if (!File.Exists(GlobalVariables.DocumentsPath + "\\Catalog.xml"))
            {
                XmlDocument _xml = new XmlDocument();
                XmlDeclaration HeaderNode = _xml.CreateXmlDeclaration("1.0", "UTF-8", null);
                XmlElement root = _xml.DocumentElement;
                _xml.InsertBefore(HeaderNode, root);
                XmlNode _catalog = _xml.CreateElement("Catalog");
                _xml.AppendChild(_catalog);
                _xml.Save(GlobalVariables.DocumentsPath + "\\Catalog.xml");
            }
        }

        private void CreateIfMissing(string path)
        {
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
        }

        public static void InitializeDatabases()
        {
            //if (!File.Exists(Configuration.PersistentData)) { lic_local.InitPersistentData(); }
            //if (!File.Exists(Configuration.LicenseTable)) { lic_local.InitLicenseFile(); }
            //if (!File.Exists(Configuration.CaseUserMembership)) { lic_local.InitCaseUserMembership(); }
            if (!File.Exists(Configuration.PersistentSettings)) File.Create(Configuration.PersistentSettings).Dispose(); // to use when converted to .ini file
        }

        public void CleanupHotKeys()
        {
            HotKeyManager _hotKey = new HotKeyManager();
            HotKey _HK_Right = _hotKey.Register(Key.Right, ModifierKeys.None);
            HotKey _HK_Left  = _hotKey.Register(Key.Left, ModifierKeys.None);
            HotKey _HK_Up    = _hotKey.Register(Key.Up, ModifierKeys.None);
            HotKey _HK_Down  = _hotKey.Register(Key.Down, ModifierKeys.None);
            _hotKey.Unregister(_HK_Right);
            _hotKey.Unregister(_HK_Left);
            _hotKey.Unregister(_HK_Up);
            _hotKey.Unregister(_HK_Down);
        }


        ///////////////////  EXIT STUFF ///////////////////
        private void Application_DispatcherUnhandledException(object sender, System.Windows.Threading.DispatcherUnhandledExceptionEventArgs e)
        {
            ExitApplication();
        }

        private void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            ExitApplication();
        }

        private void Application_Exit(object sender, ExitEventArgs e)
        {
            ExitApplication();
        }

        private void ExitApplication()
        {
            // Clear temp directory anyway
            ClearTemp();

            CaseBL CaseBusiness = new CaseBL();
            CaseBusiness.UnLoadCatalog();

            foreach (Window objWindow in Application.Current.Windows)
            {
                objWindow.Close();
            }
            return;
        }

        private void ClearTemp()
        {
            try
            {
                // Cleaning up the temp directory, avoiding the catalog
                if (GlobalVariables.TempPath != null)
                {
                    var filteredFiles = Directory.EnumerateFiles(GlobalVariables.TempPath, "*.*")
                                        .Where(file => !file.EndsWith("Catalog.xml"))
                                        .ToArray();
                    Array.ForEach(filteredFiles, File.Delete);
                }

                // Cleaning up the replay temp directory
                if (GlobalVariables.TempReplayPath != null)
                {
                    var filteredReplayFiles = Directory.EnumerateFiles(GlobalVariables.TempReplayPath, "*.*")
                                              .ToArray();
                    Array.ForEach(filteredReplayFiles, File.Delete);
                }

                // Cleaning up the audio temp directory
                if (GlobalVariables.AudioTempPath != null)
                {
                    var filteredReplayFiles = Directory.EnumerateFiles(GlobalVariables.AudioTempPath, "*.*")
                                              .ToArray();
                    Array.ForEach(filteredReplayFiles, File.Delete);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }
    }
}

